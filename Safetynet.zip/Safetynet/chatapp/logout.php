<?php

sleep(1);
"<button onclick='myFunction()' class = 'logout' >Logout</button>";

?>





<style>

.logout{
	position:relative;
	bottom:300px;
  width: 300px;
  height:50px;
  cursor:pointer;
  border-radius:50px;
  padding:10px 20px 10px 0;
  color:White;
  font-size:14px;
  text-align:left;
  text-indent:40px;
  display:block;
  margin:0 auto;
 background-color:black;

  -webkit-transition-timing-function: ease-in-out;
  -webkit-transition-duration: .4s;
  -webkit-transition-property: all;
  
  -moz-transition-timing-function: ease-in-out;
  -moz-transition-duration: .4s;
  -moz-transition-property: all;
}

.logout:hover {
 
  background-position: 65px 5px;
  text-indent: 15px;  
}
	
	
	
}



</style>