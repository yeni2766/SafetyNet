<div class = 'class'>

</div>

<div class = 'class'>
hh
</div>
<style>
.class{
	margin:10px;
	height:40px; 
	width:50px;
	position:relative;
	background-color:red;
	
	
}


</style>