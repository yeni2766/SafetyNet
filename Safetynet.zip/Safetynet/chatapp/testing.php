<div id = 'contactss1'  class = 'bb' style = 'margin:30px;'>
		
				<div class = 'message'>
				
			<div class = 'child1'>	shut up loooool
			
			
			</div>
					
					</div>
					<span style = 'position:relative; left:25px; bottom: 5px;'> <small>20/11/2021 10am</small></span>
				<div class = 'image1'>
	<img class='rounded-circle' style = 'right:120px; 'id = 'image'src = "<?php echo $result['image']; ?>" >
	</div>

	<div class = 'para'>
	<p class ='p' style = 'margin-bottom:80px; right:120px;'><?php echo $result['childfname']; ?></p><br>

					</div>
				<br>
				

					</div>
					
					<br>
				<div id = 'secondmessage'  class = 'bb' style = 'float:right; margin:10px;' >
								<div class = 'message'>
					<div class = 'child'>	hahaha
			</div>
					</div>
					<span style = 'position:relative; left:-50px; bottom: 5px;'> <small>20/11/2021 10am</small></span>
				<div class = 'image1'>
	<img class='rounded-circle' style = 'left:160px; bottom:30px; 'id = 'image'src = "<?php echo $result['image']; ?>" >
	</div>
	<div class = 'para'>
	<p class ='p' style = ' left:160px; '><?php echo $result['childfname']; ?></p><br>

					</div>
					</div>